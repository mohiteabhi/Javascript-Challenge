
const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3000;


app.use(bodyParser.json());
app.use(cors());
app.use(express.static('public')); 


const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',      
  password: 'root',  
  database: 'todo_list'
});


db.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    return;
  }
  console.log('Connected to MySQL database.');
});


app.get('/api/tasks', (req, res) => {
  const sql = 'SELECT * FROM tasks ORDER BY created_at DESC';
  db.query(sql, (err, results) => {
    if (err) {
      console.error('Error fetching tasks:', err);
      return res.status(500).json({ error: 'Database error' });
    }
    res.json(results);
  });
});


app.post('/api/tasks', (req, res) => {
  const { task_name } = req.body;
  if (!task_name) {
    return res.status(400).json({ error: 'Task name is required' });
  }
  const sql = 'INSERT INTO tasks (task_name) VALUES (?)';
  db.query(sql, [task_name], (err, result) => {
    if (err) {
      console.error('Error adding task:', err);
      return res.status(500).json({ error: 'Database error' });
    }
    res.json({
      id: result.insertId,
      task_name,
      created_at: new Date()
    });
  });
});


app.delete('/api/tasks/:id', (req, res) => {
  const taskId = req.params.id;
  const sql = 'DELETE FROM tasks WHERE id = ?';
  db.query(sql, [taskId], (err, result) => {
    if (err) {
      console.error('Error deleting task:', err);
      return res.status(500).json({ error: 'Database error' });
    }
    res.json({ message: 'Task deleted' });
  });
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
