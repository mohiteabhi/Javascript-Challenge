
document.addEventListener('DOMContentLoaded', function () {
    const inputBox = document.getElementById("input-box");
    const addBtn = document.getElementById("add-btn");
    const listContainer = document.querySelector(".list-container");
  

    function loadTasks() {
      fetch('/api/tasks')
        .then(response => response.json())
        .then(tasks => {
          listContainer.innerHTML = '';
          tasks.forEach(task => {
            const li = document.createElement("li");
            li.textContent = task.task_name;
            li.setAttribute('data-id', task.id);

            const span = document.createElement("span");
            span.innerHTML = "<i class='fa-solid fa-trash'></i>";
            li.appendChild(span);
  
            listContainer.appendChild(li);
          });
        })
        .catch(err => console.error('Error loading tasks:', err));
    }
  
    loadTasks();
  

    function addTask() {
      const taskName = inputBox.value.trim();
      if (!taskName) {
        alert("Don't be lazy!! Enter some tasks ");
        return;
      }
  
      fetch('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ task_name: taskName })
      })
        .then(response => response.json())
        .then(data => {
          const li = document.createElement("li");
          li.textContent = data.task_name;
          li.setAttribute('data-id', data.id);
  
          const span = document.createElement("span");
          span.innerHTML = "<i class='fa-solid fa-trash'></i>";
          li.appendChild(span);
  
          listContainer.prepend(li);
          inputBox.value = "";
        })
        .catch(err => console.error('Error adding task:', err));
    }
  
    addBtn.addEventListener("click", addTask);
    inputBox.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        addTask();
      }
    });
  
    listContainer.addEventListener("click", (e) => {
      let li;
      if (e.target.tagName.toUpperCase() === "LI") {
        li = e.target;
      } else if (e.target.tagName.toUpperCase() === "SPAN") {
        li = e.target.parentElement;
      } else if (e.target.tagName.toUpperCase() === "I") {
        li = e.target.parentElement.parentElement;
      }
      if (!li) return;
  
      const taskId = li.getAttribute('data-id');
      if (!taskId) return;
  
      fetch(`/api/tasks/${taskId}`, { method: 'DELETE' })
        .then(response => response.json())
        .then(() => {
          li.remove();
        })
        .catch(err => console.error('Error deleting task:', err));
    });
  });
  